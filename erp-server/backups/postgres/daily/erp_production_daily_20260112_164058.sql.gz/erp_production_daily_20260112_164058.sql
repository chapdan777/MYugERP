--
-- PostgreSQL database dump
--

\restrict hzxHeou75zkepxbYvUE17PqGzKZfNk8vr0NVRg4YqI8ohhSKVQJhuyjGGtI4sRh

-- Dumped from database version 14.20
-- Dumped by pg_dump version 14.20

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: price_modifiers_modifiertype_enum; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.price_modifiers_modifiertype_enum AS ENUM (
    'fixed_price',
    'percentage',
    'fixed_amount',
    'per_unit',
    'multiplier'
);


ALTER TYPE public.price_modifiers_modifiertype_enum OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: price_modifiers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.price_modifiers (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    code character varying(100) NOT NULL,
    "modifierType" public.price_modifiers_modifiertype_enum NOT NULL,
    value numeric(15,4) NOT NULL,
    "propertyId" integer,
    "propertyValue" character varying(255),
    priority integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp without time zone DEFAULT now() NOT NULL,
    "updatedAt" timestamp without time zone DEFAULT now() NOT NULL,
    "startDate" timestamp without time zone,
    "endDate" timestamp without time zone
);


ALTER TABLE public.price_modifiers OWNER TO postgres;

--
-- Name: price_modifiers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.price_modifiers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.price_modifiers_id_seq OWNER TO postgres;

--
-- Name: price_modifiers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.price_modifiers_id_seq OWNED BY public.price_modifiers.id;


--
-- Name: price_modifiers id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_modifiers ALTER COLUMN id SET DEFAULT nextval('public.price_modifiers_id_seq'::regclass);


--
-- Data for Name: price_modifiers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.price_modifiers (id, name, code, "modifierType", value, "propertyId", "propertyValue", priority, "isActive", "createdAt", "updatedAt", "startDate", "endDate") FROM stdin;
2	Integrity Test 2	INT_002	fixed_amount	150.0000	\N	\N	0	t	2026-01-10 18:03:11.45	2026-01-10 18:03:11.45	\N	\N
3	Integrity Test 3	INT_003	multiplier	1.2500	\N	\N	0	t	2026-01-10 18:03:11.45	2026-01-10 18:03:11.45	\N	\N
\.


--
-- Name: price_modifiers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.price_modifiers_id_seq', 3, true);


--
-- Name: price_modifiers PK_21bf8fe4138f3489e77be92e0da; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_modifiers
    ADD CONSTRAINT "PK_21bf8fe4138f3489e77be92e0da" PRIMARY KEY (id);


--
-- Name: price_modifiers UQ_3836d34c7137695cccb261287ad; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.price_modifiers
    ADD CONSTRAINT "UQ_3836d34c7137695cccb261287ad" UNIQUE (code);


--
-- Name: IDX_242a431c22c07d92dc81f389a1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_242a431c22c07d92dc81f389a1" ON public.price_modifiers USING btree ("isActive");


--
-- Name: IDX_3836d34c7137695cccb261287a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_3836d34c7137695cccb261287a" ON public.price_modifiers USING btree (code);


--
-- Name: IDX_5a87359ac30f88f43ceab9dc33; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_5a87359ac30f88f43ceab9dc33" ON public.price_modifiers USING btree ("propertyId");


--
-- Name: idx_price_modifiers_active_priority; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_modifiers_active_priority ON public.price_modifiers USING btree ("isActive", priority) WHERE ("isActive" = true);


--
-- Name: idx_price_modifiers_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_modifiers_code ON public.price_modifiers USING btree (code);


--
-- Name: idx_price_modifiers_dates; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_modifiers_dates ON public.price_modifiers USING btree ("startDate", "endDate") WHERE (("startDate" IS NOT NULL) OR ("endDate" IS NOT NULL));


--
-- Name: idx_price_modifiers_property_lookup; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_price_modifiers_property_lookup ON public.price_modifiers USING btree ("propertyId", "propertyValue") WHERE ("propertyId" IS NOT NULL);


--
-- PostgreSQL database dump complete
--

\unrestrict hzxHeou75zkepxbYvUE17PqGzKZfNk8vr0NVRg4YqI8ohhSKVQJhuyjGGtI4sRh

